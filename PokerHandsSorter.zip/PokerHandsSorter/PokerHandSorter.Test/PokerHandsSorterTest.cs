﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using PokerHandSorter;

namespace PokerHandSorter.Test
{    
    [TestClass]
    public class PokerHandsSorterTest
    {
        private PokerHandReader reader = new PokerHandReader();
        
        [TestMethod]
        public void TestFourOfAKind()
        {
            string[] hand = new string[] { "4D", "4S", "4C", "4H", "2C" };            
            Rank result = reader.CheckPairs(reader.GetCardList(hand));

            Assert.AreEqual(8, result.Value); // rank = 8
            Assert.AreEqual(4, result.HighCard); // which card
        }

        [TestMethod]
        public void TestFullHouse()
        {
            string[] hand = new string[] { "4D", "4S", "4C", "TH", "TC" };
            Rank result = reader.CheckPairs(reader.GetCardList(hand));

            Assert.AreEqual(7, result.Value); // rank = 7
            Assert.AreEqual(10, result.HighCard); // which card
        }

        [TestMethod]
        public void TestTwoPairs1()
        {
            string[] hand = new string[] { "4D", "8S", "8C", "9H", "9C" };
            Rank result = reader.CheckPairs(reader.GetCardList(hand));

            Assert.AreEqual(3, result.Value); // rank = 3
            Assert.AreEqual(9, result.HighCard); // which card            
        }

        [TestMethod]
        public void TestTwoPairs2()
        {
            string[] hand = new string[] { "4D", "9S", "9C", "8H", "8C" };
            Rank result = reader.CheckPairs(reader.GetCardList(hand));

            Assert.AreEqual(3, result.Value); // rank = 3
            Assert.AreEqual(9, result.HighCard); // which card
        }

        [TestMethod]
        public void TestStraight1()
        {
            string[] hand = new string[] { "6D", "2S", "4C", "3H", "5C" };
            Rank result = reader.CheckStraight(reader.GetCardList(hand));

            Assert.AreEqual(5, result.Value); // rank = 5
            Assert.AreEqual(6, result.HighCard); // which card
        }

        [TestMethod]
        public void TestStraight2()
        {
            string[] hand = new string[] { "9D", "TS", "JC", "QH", "KC" };
            Rank result = reader.CheckStraight(reader.GetCardList(hand));

            Assert.AreEqual(5, result.Value); // rank = 5
            Assert.AreEqual(13, result.HighCard); // which card
        }

        [TestMethod]
        public void TestStraight3()
        {
            string[] hand = new string[] { "2D", "TS", "JC", "QH", "KC" };
            Rank result = reader.CheckStraight(reader.GetCardList(hand));

            Assert.AreEqual(0, result.Value); // not a straight
        }

        [TestMethod]
        public void TestFlush1()
        {
            string[] hand = new string[] { "2D", "TS", "JC", "QH", "KC" };
            Rank result = reader.CheckFlush(hand);

            Assert.AreEqual(0, result.Value); // not a flush
        }

        [TestMethod]
        public void TestFlush2()
        {
            string[] hand = new string[] { "2D", "TD", "JD", "QD", "KD" };
            Rank result = reader.CheckFlush(hand);

            Assert.AreEqual(6, result.Value); // rank = 6
            Assert.AreEqual(13, result.HighCard); // which card
        }

        [TestMethod]
        public void TestStraightFlush()
        {
            string[] hand = new string[] { "2D", "3D", "4D", "5D", "6D" };
            Rank result = reader.CheckFlush(hand);

            Assert.AreEqual(6, result.Value); // rank = 6
            Assert.AreEqual(6, result.HighCard); // which card

            result = reader.CheckStraight(reader.GetCardList(hand));

            Assert.AreEqual(5, result.Value); // straight
            Assert.AreEqual(6, result.HighCard); // which card
        }

        [TestMethod]
        public void TestRoyalFlush()
        {
            string[] hand = new string[] { "JD", "QD", "KD", "AD", "TD" };
            Rank result = reader.CheckFlush(hand);

            Assert.AreEqual(6, result.Value); // rank = 6
            Assert.AreEqual(14, result.HighCard); // which card

            result = reader.CheckStraight(reader.GetCardList(hand));

            Assert.AreEqual(5, result.Value); // straight
            Assert.AreEqual(14, result.HighCard); // which card
        }

        [TestMethod]
        public void TestSimpleHighCard()
        {
            string[] hand1 = new string[] { "1D", "QS", "2D", "3C", "TD" };
            string[] hand2 = new string[] { "AD", "2S", "9D", "8D", "5D" };
            Assert.AreEqual(2, reader.CompareHand(hand1, hand2));
        }

        [TestMethod]
        public void TestNextHighCard1()
        {
            string[] hand1 = new string[] { "AD", "QS", "2D", "3C", "TD" };
            string[] hand2 = new string[] { "AD", "2S", "9D", "8D", "5D" };
            Assert.AreEqual(1, reader.CompareHand(hand1, hand2));
        }

        [TestMethod]
        public void TestNextHighCard2()
        {
            string[] hand1 = new string[] { "AD", "AS", "2D", "3C", "TD" };
            string[] hand2 = new string[] { "AH", "AC", "9D", "8D", "5D" };
            Assert.AreEqual(1, reader.CompareHand(hand1, hand2));
        }

        [TestMethod]
        public void TestNextHighCard3()
        {
            string[] hand1 = new string[] { "AD", "AS", "4H", "4C", "2D" };
            string[] hand2 = new string[] { "AH", "AC", "4D", "4S", "5D" };
            Assert.AreEqual(2, reader.CompareHand(hand1, hand2));
        }
    }
}
