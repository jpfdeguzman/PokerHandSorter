﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokerHandSorter
{
    public class PokerHandReader
    {
        public int CompareHand(string[] cards1, string[] cards2)
        {
            Rank rank1 = ReadHand(cards1);
            Rank rank2 = ReadHand(cards2);

            if (rank1.Value > rank2.Value || (rank1.Value == rank2.Value && rank1.HighCard > rank2.HighCard))
                return 1;
            else if (rank1.Value < rank2.Value || (rank1.Value == rank2.Value && rank1.HighCard < rank2.HighCard))
            {
                //Console.WriteLine(String.Join(", ", cards1));
                //Console.WriteLine(String.Join(", ", cards2));
                //Console.WriteLine("Rank1 = " + rank1.Value + " High = " + rank1.HighCard);
                //Console.WriteLine("Rank2 = " + rank2.Value + " High = " + rank2.HighCard);
                //Console.WriteLine();
                return 2;
            }   
            else if (rank1.Value == rank2.Value && rank1.HighCard == rank2.HighCard)
            {
                var cardList1 = GetCardList(cards1);
                var cardList2 = GetCardList(cards2);
                        
                // compare next high card until they're not the same value
                do
                {
                    cardList1.RemoveAll(item => item == rank1.HighCard);
                    cardList2.RemoveAll(item => item == rank2.HighCard);

                    rank1.HighCard = GetNextHighCard(cardList1, rank1.HighCard);
                    rank2.HighCard = GetNextHighCard(cardList2, rank2.HighCard);
                } while (rank1.HighCard == rank2.HighCard);

                return rank1.HighCard > rank2.HighCard ? 1 : 2;
            }
            else
                return 0;
        }        

        
        private Rank ReadHand(string[] cards)
        {
            var cardList = GetCardList(cards);
            var flushResult = CheckFlush(cards);
            var straightResult = CheckStraight(cardList);
            var pairsResult = CheckPairs(cardList);

            if (flushResult.Value == 6 && straightResult.Value == 5)
                return (flushResult.HighCard == 14) ? new Rank(10, 14) : new Rank( 9, straightResult.HighCard);
            else if (pairsResult.Value == 7)
                return pairsResult;
            else if (flushResult.Value == 6)
                return flushResult;
            else if (straightResult.Value == 5)
                return straightResult;
            else if (pairsResult.Value > 1)
                return pairsResult;
            else
                return GetHighCard(cardList);
        }

        private int GetNextHighCard(List<int> cardList, int prevHighCard)
        {
            var highCard = 0;

            foreach(int card in cardList)
            {
                if (card > highCard && card != prevHighCard)
                    highCard = card;
            }

            return highCard;
        }

        public Rank GetHighCard(List<int> cardList)        
        {
            int highCard = 0;

            foreach(int cardValue in cardList)
            {
                if (cardValue > highCard)
                    highCard = cardValue;
            }

            return new Rank(1, highCard);
        }

        public Rank CheckStraight(List<int> cardList)
        {            
            cardList.Sort();
            Rank result = new Rank(5, cardList[4]); // assume there's a straight, set to rank to 0 if found to be false

            for (int i = 1; i < cardList.Count; i++)
            {
                if(cardList[i] != cardList[i-1] + 1)
                {
                    result.Clear();
                    break;
                }
            }
            return result;
        }

        public Rank CheckFlush(string[] cards)
        {
            var cardList = GetCardList(cards);
            var suitArr = GetSuitList(cards).ToArray();
            cardList.Sort();
            Rank result = new Rank(6, cardList[4]); //assumed there's a flush, set rank to 0 if found to be false
            char prevSuit = suitArr[0];
            
            for(int i = 1; i < suitArr.Length; i++)
            {
                char currSuit = suitArr[i];

                if(currSuit != prevSuit)
                {
                    result.Clear();
                    break;
                }
            }
            
            return result;
        }
        /// <summary>
        /// Check if the cards has pairs in them
        /// </summary>
        /// <param name="cards"></param>
        /// <returns>
        /// 0 - no pairs
        /// 2 - one pair
        /// 3 - 2 pairs
        /// 4 - three of a kind
        /// 7 - full house
        /// 8 - four of a kind
        /// </returns>
        public Rank CheckPairs(List<int> cardList)
        {
            Rank result = new Rank(0, 0);
                        
            Dictionary<int, int> unique = new Dictionary<int, int>();            

            foreach(int cardValue in cardList)
            {
                if (unique.ContainsKey(cardValue))
                    unique[cardValue] += 1;
                else
                    unique.Add(cardValue, 1);
            }                       

            bool threeFound = false;
            bool pairFound = false;

            foreach(KeyValuePair<int, int> kvp in unique)
            {
                if (kvp.Value == 4)
                {
                    result.Value = 8;
                    result.HighCard = kvp.Key;
                }
                else if (kvp.Value == 3) {
                    if (pairFound) // full house
                    {
                        result.Value = 7;
                        result.HighCard = kvp.Key;
                    }
                    else // 3 of a kind
                    {
                        threeFound = true;
                        result.Value = 4;
                        result.HighCard = kvp.Key;
                    }
                }
                else if (kvp.Value == 2)
                {
                    if (threeFound) // full house
                    {
                        result.Value = 7;
                        result.HighCard = kvp.Key;
                    }
                    else if (pairFound) // 2 pairs
                    {
                        result.Value = 3;
                        if (kvp.Key > result.HighCard)
                            result.HighCard = kvp.Key;
                    }
                    else // 1 pair
                    {
                        pairFound = true;
                        result.Value = 2;
                        result.HighCard = kvp.Key;
                    }
                }                
            }
            
            return result;
        }
       
        private int GetNumericValue(string card)
        {
            char[] ch = card.ToCharArray();

            if (ch.Length == 2)
            {
                if (new char[] { 'D', 'H', 'S', 'C' }.Contains(ch[1]))
                {
                    if (Char.IsNumber(ch[0]))
                        return Convert.ToInt32(Char.GetNumericValue(ch[0]));
                    else if (Char.IsLetter(ch[0]))
                    {
                        switch (ch[0])
                        {
                            case 'T':
                                return 10;
                            case 'J':
                                return 11;
                            case 'Q':
                                return 12;
                            case 'K':
                                return 13;
                            case 'A':
                                return 14;
                            default:
                                return 0;
                        }
                    }
                }
            }

            return 0;
        }

        public List<int> GetCardList(string[] cards)
        {
            List<int> cardList = new List<int>();
            foreach (string card in cards)
            {
                cardList.Add(GetNumericValue(card));
            }

            return cardList;
        }

        private List<char> GetSuitList(string[] cards)
        {
            List<char> suitList = new List<char>();

            foreach(string card in cards)
            {
                suitList.Add(card.ToArray()[1]);
            }

            return suitList;
        }
    }
}
