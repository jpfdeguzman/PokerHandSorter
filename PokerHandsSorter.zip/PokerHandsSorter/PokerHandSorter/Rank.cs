﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokerHandSorter
{
    public class Rank
    {
        private int _value;  
        public int Value    
        {
            get => _value;
            set => _value = value;
        }

        private int _highCard;
        public int HighCard
        {
            get => _highCard;
            set => _highCard = value;
        }

        public Rank(int value, int highCard)
        {
            this.Value = value;
            this.HighCard = highCard;
        }

        public void Clear()
        {
            this.Value = 0;
            this.HighCard = 0;
        }
    }
}
