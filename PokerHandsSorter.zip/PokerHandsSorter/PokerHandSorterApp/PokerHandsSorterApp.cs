﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PokerHandSorter;

namespace PokerHandSorterApp
{
    class PokerHandSorterApp
    {
        static void Main(string[] args)
        {
            var path = args.Length > 0 ? args[0] : "C:\\Users\\JohndeGuzman\\source\\repos\\PokerHandsSorter\\poker-hands.txt";

            if (File.Exists(path))
            {
                string[] lines = System.IO.File.ReadAllLines(path);
                PokerHandReader handReader = new PokerHandReader();

                int wins1 = 0;
                int wins2 = 0;

                foreach(string line in lines)
                {
                    //Console.WriteLine(line);
                    if(line.Length == 29) //9C 9D 8D 7C 3C 2S KD TH 9H 8H
                    {
                        string[] cards1 = line.Substring(0, 14).Split(' ');
                        string[] cards2 = line.Substring(15, 14).Split(' ');

                        var result = handReader.CompareHand(cards1, cards2);
                        
                        switch(result)
                        {
                            case 1:
                                wins1++;
                                break;
                            case 2:
                                wins2++;
                                break;
                            default:
                                break;
                        }    
                    }
                }

                Console.WriteLine("Player 1: " + wins1 + " hands");
                Console.WriteLine("Player 2: " + wins2 + " hands");
                Console.WriteLine();
                Console.Write("Press ENTER key to continue.");
                Console.ReadLine();
            }
            else
            {
                Console.Error.WriteLine("Invalid input path.");
            }
        }
    }
}
